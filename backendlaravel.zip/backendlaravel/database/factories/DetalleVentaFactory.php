<?php

namespace Database\Factories;

use App\Models\DetalleVenta;
use App\Models\Producto;
use Illuminate\Database\Eloquent\Factories\Factory;

class DetalleVentaFactory extends Factory
{
    protected $model = DetalleVenta::class;

    public function definition(): array
    {
        $producto = Producto::inRandomOrder()->first();
        $cantidad = $this->faker->numberBetween(1, 5);
        $precio = $producto->precio;
        $subtotal = $cantidad * $precio;

        return [
            'producto_id' => $producto->id,
            'cantidad' => $cantidad,
            'precio_unitario' => $precio,
            'subtotal' => $subtotal,
        ];
    }
}
