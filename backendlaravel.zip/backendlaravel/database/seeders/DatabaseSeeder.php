<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Cliente;
use App\Models\Producto;
use App\Models\Venta;
use App\Models\DetalleVenta;



class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::factory(3)->create();

        Cliente::factory(10)->create();

        Producto::factory(20)->create();

        Venta::factory(15)->create()->each(function ($venta) {
            DetalleVenta::factory(rand(1, 5))->create([
                'venta_id' => $venta->id
            ]);

            $venta->total = $venta->detalles->sum('subtotal');
            $venta->save();
        });
    }
}
