

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Detalle de la Venta #<?php echo e($venta->id); ?></h3>
    </div>

    <div class="card-body">

        <p><strong>Cliente:</strong> <?php echo e($venta->cliente->nombre); ?></p>
        <p><strong>Vendedor:</strong> <?php echo e($venta->user->name); ?></p>
        <p><strong>Fecha:</strong> <?php echo e($venta->created_at->format('d/m/Y H:i')); ?></p>

        <hr>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Precio</th>
                    <th>Cantidad</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $venta->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($detalle->producto->nombre); ?></td>
                    <td>$<?php echo e($detalle->precio_unitario); ?></td>
                    <td><?php echo e($detalle->cantidad); ?></td>
                    <td>$<?php echo e($detalle->subtotal); ?></td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <h4 class="text-right mt-3">
            Total: <strong>$<?php echo e($venta->total); ?></strong>
        </h4>

        <a href="<?php echo e(route('ventas.index')); ?>" class="btn btn-secondary mt-3">
            <i class="fas fa-arrow-left"></i> Volver
        </a>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Antita\Desktop\Backend\backendlaravel\resources\views/ventas/show.blade.php ENDPATH**/ ?>