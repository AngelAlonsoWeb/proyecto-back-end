

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between">
        <h3 class="card-title">Ventas</h3>

        <a href="<?php echo e(route('ventas.create')); ?>" class="btn btn-success">
            <i class="fas fa-plus"></i> Nueva Venta
        </a>
    </div>

    <div class="card-body">
        <form method="GET" class="mb-3">
            <div class="row">
                <div class="col-md-4">
                    <select name="cliente_id" class="form-control">
                        <option value="">-- Todos los clientes --</option>
                        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cliente->id); ?>"
                            <?php echo e(request('cliente_id') == $cliente->id ? 'selected' : ''); ?>>
                            <?php echo e($cliente->nombre); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-2">
                    <button class="btn btn-primary">
                        <i class="fas fa-filter"></i> Buscar
                    </button>
                </div>
            </div>
        </form>

        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Cliente</th>
                    <th>Vendedor</th>
                    <th>Total</th>
                    <th>Fecha</th>
                    <th width="120">Ver a Detalle</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($venta->id); ?></td>
                    <td><?php echo e($venta->cliente->nombre); ?></td>
                    <td><?php echo e($venta->user->name); ?></td>
                    <td>$<?php echo e($venta->total); ?></td>
                    <td><?php echo e($venta->created_at->format('d/m/Y')); ?></td>
                    <td class="text-center">
                        <a href="<?php echo e(route('ventas.show', $venta)); ?>" class="btn btn-sm btn-info">
                            <i class="fas fa-eye"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="d-flex justify-content-center mt-3">
            <?php echo e($ventas->links('pagination::bootstrap-4')); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Antita\Desktop\Backend\backendlaravel\resources\views/ventas/index.blade.php ENDPATH**/ ?>