<?php

namespace App\Http\Controllers;

use App\Models\Venta;
use App\Models\Cliente;
use App\Models\Producto;
use App\Models\DetalleVenta;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class VentaController extends Controller
{
    public function index(Request $request)
    {
        $clientes = Cliente::all();

        $ventas = Venta::with('cliente')
            ->when($request->cliente_id, function ($query) use ($request) {
                $query->where('cliente_id', $request->cliente_id);
            })
            ->latest()
            ->paginate(8)
            ->withQueryString();

        return view('ventas.index', compact('ventas', 'clientes'));
    }

    public function show(Venta $venta)
    {
        $venta->load(['cliente', 'user', 'detalles.producto']);

        return view('ventas.show', compact('venta'));
    }
    public function store(Request $request)
    {
        $venta = Venta::create([
            'cliente_id' => $request->cliente_id,
            'user_id' => Auth::id(),
            'total' => 0,
        ]);

        $total = 0;

        foreach ($request->productos as $producto_id => $cantidad) {

            if ($cantidad > 0) {

                $producto = Producto::findOrFail($producto_id);
                $subtotal = $producto->precio * $cantidad;

                DetalleVenta::create([
                    'venta_id' => $venta->id,
                    'producto_id' => $producto->id,
                    'precio_unitario' => $producto->precio,
                    'cantidad' => $cantidad,
                    'subtotal' => $subtotal,               
                ]);

                $total += $subtotal;
            }
        }

        $venta->update(['total' => $total]);

        return redirect()->route('ventas.show', $venta);
    }
}
