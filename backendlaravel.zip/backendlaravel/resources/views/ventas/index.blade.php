@extends('layouts.admin')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between">
        <h3 class="card-title">Ventas</h3>

        <a href="{{ route('ventas.create') }}" class="btn btn-success">
            <i class="fas fa-plus"></i> Nueva Venta
        </a>
    </div>

    <div class="card-body">
        <form method="GET" class="mb-3">
            <div class="row">
                <div class="col-md-4">
                    <select name="cliente_id" class="form-control">
                        <option value="">-- Todos los clientes --</option>
                        @foreach($clientes as $cliente)
                        <option value="{{ $cliente->id }}"
                            {{ request('cliente_id') == $cliente->id ? 'selected' : '' }}>
                            {{ $cliente->nombre }}
                        </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-2">
                    <button class="btn btn-primary">
                        <i class="fas fa-filter"></i> Buscar
                    </button>
                </div>
            </div>
        </form>

        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Cliente</th>
                    <th>Vendedor</th>
                    <th>Total</th>
                    <th>Fecha</th>
                    <th width="120">Ver a Detalle</th>
                </tr>
            </thead>
            <tbody>
                @foreach($ventas as $venta)
                <tr>
                    <td>{{ $venta->id }}</td>
                    <td>{{ $venta->cliente->nombre }}</td>
                    <td>{{ $venta->user->name }}</td>
                    <td>${{ $venta->total }}</td>
                    <td>{{ $venta->created_at->format('d/m/Y') }}</td>
                    <td class="text-center">
                        <a href="{{ route('ventas.show', $venta) }}" class="btn btn-sm btn-info">
                            <i class="fas fa-eye"></i>
                        </a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>

        <div class="d-flex justify-content-center mt-3">
            {{ $ventas->links('pagination::bootstrap-4') }}
        </div>
    </div>
</div>
@endsection