@extends('layouts.admin')

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Detalle de la Venta #{{ $venta->id }}</h3>
    </div>

    <div class="card-body">

        <p><strong>Cliente:</strong> {{ $venta->cliente->nombre }}</p>
        <p><strong>Vendedor:</strong> {{ $venta->user->name }}</p>
        <p><strong>Fecha:</strong> {{ $venta->created_at->format('d/m/Y H:i') }}</p>

        <hr>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Precio</th>
                    <th>Cantidad</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                @foreach($venta->detalles as $detalle)
                <tr>
                    <td>{{ $detalle->producto->nombre }}</td>
                    <td>${{ $detalle->precio_unitario }}</td>
                    <td>{{ $detalle->cantidad }}</td>
                    <td>${{ $detalle->subtotal }}</td>

                </tr>
                @endforeach
            </tbody>
        </table>

        <h4 class="text-right mt-3">
            Total: <strong>${{ $venta->total }}</strong>
        </h4>

        <a href="{{ route('ventas.index') }}" class="btn btn-secondary mt-3">
            <i class="fas fa-arrow-left"></i> Volver
        </a>

    </div>
</div>
@endsection