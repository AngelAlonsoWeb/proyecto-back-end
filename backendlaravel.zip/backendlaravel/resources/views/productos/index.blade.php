@extends('layouts.admin')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title">Productos</h3>

        <a href="{{ route('productos.create') }}" class="btn btn-success">
            <i class="fas fa-plus"></i> Nuevo Producto
        </a>
    </div>

    <div class="card-body">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th width="140">Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach($productos as $producto)
                <tr>
                    <td>{{ $producto->id }}</td>
                    <td>{{ $producto->nombre }}</td>
                    <td>${{ $producto->precio }}</td>
                    <td>{{ $producto->stock }}</td>
                    <td class="text-center">

                        <a href="{{ route('productos.edit', $producto) }}"
                            class="btn btn-sm btn-primary">
                            <i class="fas fa-edit"></i>
                        </a>

                        <form action="{{ route('productos.destroy', $producto) }}"
                            method="POST"
                            style="display:inline-block">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-sm btn-danger"
                                onclick="return confirm('¿Eliminar producto?')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>

                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>

        <!-- 👇 AQUÍ VA LA PAGINACIÓN -->
        <div class="d-flex justify-content-center mt-3">
            {{ $productos->links('pagination::bootstrap-4') }}
        </div>
    </div>

</div>
</div>
@endsection

@section('scripts')
<script>
    $(function() {
        $('#tablaProductos').DataTable({
            language: {
                search: "Buscar:",
                lengthMenu: "Mostrar _MENU_ registros",
                info: "Mostrando _START_ a _END_ de _TOTAL_",
                paginate: {
                    next: "Siguiente",
                    previous: "Anterior"
                }
            }
        });
    });
</script>
@endsection