<?php
use App\Http\Controllers\Api\ClienteController;
use Illuminate\Support\Facades\Route;

Route::resource('clientes', ClienteController::class);

